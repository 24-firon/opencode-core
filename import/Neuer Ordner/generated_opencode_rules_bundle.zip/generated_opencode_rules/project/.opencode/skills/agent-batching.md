---
name: agent-batching
description: Load this skill before launching sub-agents, splitting large tasks, or deciding how much work a single batch should contain.
---

# Agent Batching Protocol

## Goal
Prevent monolithic, opaque, and expensive agent runs. Preserve operator control, reviewability, and token efficiency.

## Before Launch
Estimate:
- files to read
- files to write
- likely tool calls
- expected risk level
- whether the task is analysis, patching, or verification

## Batch Sizes
- Small batch: 3–5 atomic steps
- Medium batch: 6–10 steps
- Larger than 15 meaningful steps: forbidden without explicit approval

## Strict Separation
Do not mix these phases in one uncontrolled run:
1. Analysis
2. Approval
3. Patching
4. Verification

Recommended pattern:
- Batch A: analysis and conflict map
- Stop and report
- Batch B: approved patch set
- Stop and report
- Batch C: verification and follow-up

## Progress Reports
After each batch report:
- what was completed
- what remains
- key risks or blockers
- recommended next batch

## Scope Discipline
Sub-agents inherit exact scope. No silent expansion of file scope, system scope, or responsibility.
