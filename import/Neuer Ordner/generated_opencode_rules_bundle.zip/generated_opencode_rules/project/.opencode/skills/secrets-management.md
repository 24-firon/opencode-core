---
name: secrets-management
description: Load this skill whenever you touch API keys, vault integration, environment configuration, auth secrets, or outbound HTTP settings.
---

# Secrets and Boundary Security

## Core Rules
- Never hardcode secrets.
- Never print tokens, API keys, passwords, or secret payloads.
- Prefer dynamic secret injection or approved secret storage over committed local files.
- Treat `.env` usage cautiously and only when it matches the project policy.

## Boundary Validation
- Validate input at system boundaries.
- For TypeScript, use schema validation where the project expects it.
- For external HTTP calls, ensure timeouts exist.

## Output Discipline
When discussing secret-related setup, use placeholders, not live values.
When rotating or moving secrets, document the operational impact.

## Forbidden
- committing secrets
- inventing env names without checking the codebase
- assuming a local JSON mock is acceptable if a real persistent system already exists
