---
name: handover-protocol
description: Load this skill when preparing a session transition, updating the project brain, or handing work to another agent or a future session.
---

# Handover Protocol

## Purpose
A handover must preserve reality across sessions without forcing the next agent to reconstruct state from chat history.

## Session Start Duty
At the beginning of a new session, load the relevant handover files before implementation.
Primary handover target in this repository:
- `.opencode/knowledge/BRAIN_UPLOAD.md`

## Session End Duty
Before ending a session:
- make sure the architectural claims still match the file tree
- make open tasks explicit
- record blockers and partial progress
- record what the next session should do first

## Separation of Concerns
Keep these categories distinct:
- future plan
- current checklist / operational status
- historical reality / what actually happened

Do not rewrite the past just to make the narrative tidy.

## Append-First Rule
Prefer appending or explicitly updating handover files over silently deleting important historical context.
If large reductions are needed, use the memory-shrink process.
