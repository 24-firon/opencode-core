---
name: memory-shrink
description: Load this skill when handover files, status logs, or session memory documents become too large and need safe reduction without losing critical context.
---

# Memory Shrink Protocol

## Core Rule
Archive first, shrink later.
Never compress active project memory without preserving the full source first.

## Required Sequence
1. Preserve the current full version.
2. Prepare a reduced draft.
3. Present the reduction logic.
4. Obtain approval if the reduction is substantial.
5. Only then replace the active version.

## Relevance Tiers
- Tier 1: current sprint, full detail retained
- Tier 2: recently completed, concise bullet summary
- Tier 3: older context, condensed to rationale and impact
- Tier 4: archived only, removed from active file with a discoverable pointer

## Forbidden
- blind deletion of historical context
- rewriting history to hide mistakes
- summarizing away unresolved constraints
