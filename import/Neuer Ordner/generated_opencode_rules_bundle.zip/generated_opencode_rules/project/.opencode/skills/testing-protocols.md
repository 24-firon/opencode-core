---
name: testing-protocols
description: Load this skill whenever you write tests, modify critical logic, run QA gates, or decide whether a change is complete.
---

# Testing and QA Protocols

## Definition of Done
A meaningful code change is not done when it compiles in your head. It is done when the relevant verification passed.

## Minimum Expectations
When relevant to the changed area, verify:
- syntax validity
- placeholder/stub absence
- lint cleanliness
- build/typecheck success
- security scan success where available
- tests passing
- coverage expectations for core logic

## 7-Gates Alignment
If the repository exposes a 7-gates or equivalent QA pipeline, treat it as mandatory.
Typical order:
1. syntax
2. placeholder scan
3. lint
4. build/typecheck
5. security scan
6. tests/coverage
7. evidence completeness

## Testing Style
- cover edge cases
- cover null/empty/boundary inputs
- avoid fake success tests
- do not silently lower quality bars to make the pipeline green

## Reporting
State exactly:
- what you ran
- what passed
- what failed
- what remains unverified
