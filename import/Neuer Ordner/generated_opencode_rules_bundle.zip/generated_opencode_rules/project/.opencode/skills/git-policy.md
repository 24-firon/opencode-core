---
name: git-policy
description: Load this skill whenever you run git status, diff, add, commit, push, pull, reset, clean, branch, merge, or rebase operations.
---

# Git Safety and Commit Discipline

## Core Laws
- Use Conventional Commits: `type(scope): description`.
- Never use vague commit messages such as `update`, `fixes`, `misc`, or `wip`.
- Review diffs before commit.
- Do not perform destructive git operations without explicit user approval.

## Mandatory Pre-Commit Sequence
1. Run `git status` and confirm scope.
2. Review the staged diff.
3. Check that no secrets, dumps, temporary files, or unrelated edits are staged.
4. Only then prepare the commit message.

## Safety Lock
These commands are high-risk and require a separate approval step:
- `git reset --hard`
- `git clean -fd`
- force-pushes
- destructive history rewrites on shared branches

## Commit Hygiene
- Keep unrelated changes out of the same commit.
- Offer a commit after a meaningful logical block, not after every trivial keystroke.
- Prefer small, reviewable commits over large mixed bundles.

## Reporting
When a git action is taken, report:
- branch/context
- what changed
- whether the diff was reviewed
- whether risk was involved
