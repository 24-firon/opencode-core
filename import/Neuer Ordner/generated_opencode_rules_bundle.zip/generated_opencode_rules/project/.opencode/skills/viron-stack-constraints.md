---
name: viron-stack-constraints
description: Load this skill when working on Viron-specific runtime behavior, async integration, queueing, ports, or stack-specific implementation constraints.
---

# Viron Stack Constraints

## Zero Guessing
Do not invent IPs, ports, schema names, queue names, or service contracts.
Verify them in the actual repository state.

## Async and Runtime Discipline
- Keep async flows non-blocking.
- Do not introduce architecture that blocks the main event loop without strong reason.
- Respect stack-native async patterns.

## Scope Boundaries
Touch only files within the approved change scope.
Do not widen the patch into adjacent systems just because you noticed additional debt.

## Reporting Preference
For technical comparisons and runtime options, prefer concise tables over large prose blocks.

## Quality Gate Reminder
Before write-heavy or infrastructure-sensitive changes:
- plan approved
- target paths verified
- local build/typecheck path known
- lint path known
