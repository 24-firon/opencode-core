---
name: three-zone-workflow
description: Load this skill before changing important project files when drafts, preview stages, or operator review checkpoints are needed.
---

# Three-Zone Workflow

## Goal
Avoid blind overwrites of original files and keep changes reviewable.

## Zone 1 — Brain
Use temporary thinking space for analysis, plans, and rough drafts.
No project originals are changed here.

## Zone 2 — Draft/WIP
Create an isolated draft artifact in a reviewable workspace such as:
- `src/_wip/`
- `docs/drafts/`
- `ops/patches/`

The original file remains untouched.

## Zone 3 — Original
Only after review and explicit go-ahead should the approved draft be merged into the real target file.
After the merge, inspect the diff.

## Use Cases
- large refactors
- risky content rewrites
- generated or AI-assisted patch proposals
- documentation rewrites with structure changes
