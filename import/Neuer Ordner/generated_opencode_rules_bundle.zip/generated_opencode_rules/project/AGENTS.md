# LOCAL GOVERNANCE — Hybrid Swarm Repository

## 1. Repository Identity
This repository implements a hybrid swarm architecture for AI-assisted software engineering.

Current architecture layers:
- Tier 3: `projects/tier3-base-swarm/` = stable execution baseline.
- Tier 2: `projects/tier2-advanced-swarm/` = active implementation focus.
- Tier 1: future architecture only. Do not treat it as active delivery scope.

At session start you must first read:
1. `AGENTS.md`
2. `.opencode/knowledge/BRAIN_UPLOAD.md`
3. Relevant nearby source files and configs for the task

## 2. Root Hygiene
- The repository root must remain clean.
- Do not create scratch files, dump files, ad-hoc notes, or operational scripts in the root.
- New operational, helper, migration, and maintenance scripts must go to `ops/scripts/`.
- Do not place new operational scripts in `.opencode/scripts/`.
- If an existing legacy system script already lives in `.opencode/scripts/`, treat it as a protected exception unless the user explicitly requests migration.

## 3. Development Boundaries
- Active implementation happens inside `projects/tier2-advanced-swarm/` and `projects/tier3-base-swarm/`.
- Tier 2 is the current build target.
- Tier 3 must remain functional and must not be destabilized while Tier 2 evolves.
- Do not move active implementation logic back into the root.

## 4. Protected Infrastructure
These locations are protected and must not be casually altered, deleted, or “cleaned up”:
- `.hive/`
- `.hivemind/`
- `.agents/`
- `.claude/`
- `.cursor/`
- `.gemini/`
- `.opencode/knowledge/`

If you suspect one of these areas needs change, stop and ask.

## 5. Source of Truth
- `.hive/` is the authoritative event/state layer.
- Treat projected plan artifacts as derived, not primary truth.
- Do not invent parallel state-tracking systems if an approved one already exists.
- `BRAIN_UPLOAD.md` is the session-handover and short-term architectural reality file. Keep it aligned with the real repo state.

## 6. Current Priority
Your primary near-term mission is to advance Tier 2 toward a usable orchestrator by improving:
- DAG execution
- dependency resolution
- task scheduling
- Swarm Mail / queue coordination
- suspend/resume continuity
- prompt assembly / blueprint routing

## 7. Working Style
- Analyze before editing.
- Keep diffs minimal and intentional.
- Match the local code style of the touched area.
- Use config-driven solutions where practical.
- Do not hardcode tenant-specific or environment-specific values into generic components.

## 8. Verification Discipline
Before claiming completion for a meaningful code change, run the relevant local checks when available:
- syntax / parsing
- linting
- type/build checks
- tests
- security scan
- evidence/report artifacts when required

If the repository exposes a formal QA pipeline, treat it as mandatory.

## 9. Documentation Duty
When architectural or operational reality changes, update the durable project memory:
- `.opencode/knowledge/BRAIN_UPLOAD.md`
- `docs/DECISION_LOG.md` if used by the project
- task/handover files if they are part of the active workflow

Do not let critical knowledge die only in chat history.

## 10. Skill Loading Policy
Do not carry every specialized rule in the base context.
Load focused skills from `.opencode/skills/` when the task requires them.

Recommended skill routing:
- Git operations -> `git-policy`
- Agent launch sizing / delegation -> `agent-batching`
- Session transition -> `handover-protocol`
- Shrinking large handover files -> `memory-shrink`
- Safe staging before final edits -> `three-zone-workflow`
- QA and testing expectations -> `testing-protocols`
- Secrets, vaults, and env discipline -> `secrets-management`
- Viron-specific async/runtime constraints -> `viron-stack-constraints`
