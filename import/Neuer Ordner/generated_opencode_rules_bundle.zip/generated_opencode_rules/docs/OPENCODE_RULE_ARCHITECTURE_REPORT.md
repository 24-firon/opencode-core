# OpenCode-Regelarchitektur — Gesamtbericht

## Zweck dieses Berichts
Dieser Bericht dient als übergreifende, erklärende Begleitdatei für das generierte OpenCode-Regelsystem. Er beschreibt nicht nur, **welche** Dateien existieren, sondern auch **warum** sie so aufgeteilt wurden, welche Abhängigkeiten bestehen, wo Chancen liegen und an welchen Stellen typische Fehlkonfigurationen drohen.

---

## 1. Ausgangslage
Im vorliegenden System treffen mehrere Regelquellen aufeinander:
- eine bereits ausgearbeitete `AGENTS.md` für den Hybrid-Swarm-Betrieb,
- mehrere historische „Legacy Gold“-Regelwerke,
- umfassende „all_in_one“-Konsolidierungen für Verhalten, Methodik, Handover, Git-Sicherheit und Multi-Agent-Koexistenz.

Das Kernproblem solcher Sammlungen ist nicht in erster Linie fehlende Qualität, sondern **fehlende Schichtung**. Wenn alles gleichzeitig immer geladen wird, entsteht ein überfrachteter Basiskontext. Das führt typischerweise zu drei Problemen:
1. höhere Kontextkosten,
2. schlechtere Priorisierung durch das Modell,
3. zunehmende Unschärfe bei der Frage, welche Regel gerade global und welche projektspezifisch ist.

Die hier erzeugte Struktur beantwortet genau dieses Problem durch eine **Dreiteilung** in globale Regeln, lokale Repo-Regeln und Skills.

---

## 2. Die drei Ebenen des Systems

### 2.1 Globale Ebene
Die globale Datei `~/.config/opencode/AGENTS.md` ist die immer aktive Grundverfassung. Sie definiert den Charakter des Agenten als verantwortlichen, skeptischen Senior Engineer.

Dorthin gehören nur Regeln, die unabhängig vom konkreten Repository gelten, zum Beispiel:
- Anti-Halluzinations-Prinzip,
- Read-before-write,
- Safety-over-obedience,
- Kommunikations- und Notfallprotokolle,
- Git-Grundhygiene,
- Plan-vor-Ausführung.

Der Vorteil dieser Schicht ist Konsistenz über mehrere Projekte hinweg. Der Nachteil einer zu großen globalen Datei wäre, dass sie ungewollt repo-spezifische Annahmen mit sich herumschleppt. Deshalb wurde sie hier bewusst auf fundamentale Verhaltensgesetze reduziert.

### 2.2 Lokale Ebene
Die lokale `AGENTS.md` im Repo-Root ist die operative Verfassung dieses konkreten Projekts. Sie beantwortet Fragen wie:
- Was ist Tier 2, Tier 3, Tier 1?
- Welche Verzeichnisse sind aktiv?
- Welche Ordner sind tabu?
- Wo liegt die Session-Wahrheit?
- Welche Mission ist aktuell priorisiert?

Diese Schicht ist der Ort für Architekturgrenzen und Repo-spezifische Verbote. Genau hier gehört zum Beispiel die Regel hin, dass neue operative Skripte ausschließlich nach `ops/scripts/` gehören und der Root clean bleiben muss.

### 2.3 Skill-Ebene
Skills sind fokussierte Spezialregelpakete mit YAML-Header. Sie dienen dem **On-Demand-Laden**. Das bedeutet: Ein Agent muss nicht permanent sämtliche Git-, Handover-, Batching-, Testing- oder Secrets-Regeln im Hauptkontext tragen. Stattdessen wird nur der gerade benötigte Ausschnitt zugeschaltet.

Das ist vor allem dann stark, wenn:
- der Orchestrator einen Router nutzt,
- verschiedene Sub-Agenten unterschiedliche Spezialregeln brauchen,
- man Kontextfenster sauber halten möchte,
- dieselbe Spezialregel projektübergreifend wiederverwendbar sein soll.

---

## 3. Warum YAML-Header nur bei Skills sinnvoll sind
Ein häufiger Denkfehler ist, YAML-Header überall einführen zu wollen. Für die klassischen `AGENTS.md`-Dateien ist das nicht nötig und auch konzeptionell wenig hilfreich. Die Basisdateien sind stets aktiv und werden nicht geroutet, sondern direkt als Grundverfassung gelesen.

Skills dagegen profitieren von YAML, weil dort Name und Beschreibung die Routing-Oberfläche bilden. Der Router oder Orchestrator kann anhand kurzer Beschreibungen entscheiden, welcher Skill geladen werden sollte, ohne dessen Volltext ständig mitzuschleppen.

Der YAML-Header ist also nicht „Kosmetik“, sondern eine **Adressierungs- und Aktivierungsstruktur**.

---

## 4. Abhängigkeiten zwischen den Dateien

| Ebene | Datei | Funktion | Abhängigkeit |
|---|---|---|---|
| Global | `~/.config/opencode/AGENTS.md` | Immer aktive Grundverfassung | Keine Repo-Abhängigkeit |
| Lokal | `<repo>/AGENTS.md` | Repo-spezifische Architekturregeln | Kennt Repo-Struktur und `BRAIN_UPLOAD.md` |
| Skill | `.opencode/skills/*.md` | Spezialwissen bei Bedarf | Wird über Aufgabe/Router/Orchestrator geladen |
| Wissen | `.opencode/knowledge/BRAIN_UPLOAD.md` | Session-Handover und laufende Realität | Muss mit Dateisystem synchron bleiben |

Wichtig ist dabei: **Skills ersetzen weder globale noch lokale Regeln**. Sie ergänzen sie. Globale Regeln definieren Verhalten, lokale Regeln definieren Repo-Grenzen, Skills definieren Spezialprotokolle.

---

## 5. Die wichtigsten inhaltlichen Entscheidungen

### 5.1 Warum `ops/scripts/` so hart priorisiert wurde
In den bisherigen Sessions ist deutlich geworden, dass Agents dazu neigen, Skripte im Root oder in agentnahen Verzeichnissen zu verstreuen. Das verschlechtert Auffindbarkeit, Repo-Hygiene und spätere Wartung. Deshalb ist `ops/scripts/` hier nicht nur eine Empfehlung, sondern eine harte Platzierungsregel.

### 5.2 Warum `.opencode/scripts/` nur als Ausnahme genannt wird
Historisch gewachsene Systemskripte können dort existieren. Der Fehler wäre, entweder alles dorthin zu verlagern oder den Ordner pauschal zu verbieten, obwohl eine Altlast real vorhanden ist. Die gewählte Formulierung schützt deshalb den Bestand, verbietet aber neue operative Skripte an dieser Stelle.

### 5.3 Warum Tier 1 nicht in die operative Basisschicht gehört
Tier 1 ist konzeptionell interessant, aber für die aktuelle Delivery-Richtung nicht unmittelbar relevant. Wenn Tier 1 bereits in der Basisschicht als aktiver Arbeitsbereich behandelt würde, verwässert das die Priorität von Tier 2 und erhöht die Ablenkungsgefahr.

### 5.4 Warum Git, Batching und Handover als Skills ausgelagert wurden
Diese Themen sind wichtig, aber nicht bei jedem einzelnen Task zugleich nötig. Gerade Git-Policy oder Memory-Shrink-Regeln sind typischerweise **phasenabhängig**. Als Skill bleiben sie präzise und abrufbar, ohne den Grundkontext permanent aufzublähen.

---

## 6. Community-nahe Umsetzung vs. Theorie
In der Praxis nutzen erfahrene OpenCode-Anwender die Basisregeln eher kurz und laden Spezialwissen selektiv nach. Der Grund ist einfach: Große, monolithische Systemprompts werden mit zunehmender Länge zwar vollständiger, aber nicht automatisch wirksamer. Sehr häufig leidet die Priorisierung in langen „Alles-immer“-Prompts.

Die hier erzeugte Struktur folgt deshalb einem pragmatischen Muster:
- **wenig, aber hart** in Global,
- **konkret und repo-spezifisch** in Local,
- **spezialisiert und nachladbar** in Skills.

Das ist keine akademische Trennung, sondern eine betriebliche Optimierung gegen Kontextverlust, Trägheit und Regelverwässerung.

---

## 7. Probleme und Risiken

### 7.1 Risiko: Zu viele Basisregeln
Wenn die globale und lokale `AGENTS.md` zusammen wieder zu groß werden, landet man faktisch wieder in einem Monolithen. Dann verliert man die Vorteile des Skill-Ansatzes.

### 7.2 Risiko: Skills werden nie aktiv geladen
Wenn der Orchestrator keine klare Skill-Routing-Logik nutzt oder die Skill-Beschreibungen zu schwach formuliert sind, existieren Skills zwar physisch, wirken aber operativ kaum.

### 7.3 Risiko: Handover driftet von der Realität weg
`BRAIN_UPLOAD.md` ist nur dann wertvoll, wenn es regelmäßig an die echte Repo-Lage angepasst wird. Ein veraltetes Brain erzeugt Fehlentscheidungen mit hoher Sicherheit.

### 7.4 Risiko: Regeln ohne technische Durchsetzung
Regeln allein sind mächtig, aber Guardrails über Plugins/Hooks können Verstöße zusätzlich technisch abfangen. Gerade Root-Hygiene oder Script-Platzierung profitieren enorm von pluginbasierten Checks.

---

## 8. Potenziale

### 8.1 Sauberer Orchestrator-Betrieb
Mit dieser Struktur kann ein Sisyphus-ähnlicher Orchestrator oder ein eigener Router viel zielgerichteter arbeiten. Die Basisschicht bleibt klein, während Spezialwissen präzise zugeladen wird.

### 8.2 Bessere Session-Wechsel
Durch das Handover-Protokoll und die klare Abgrenzung von dauerhafter Verfassung vs. laufender Session-Realität werden Session-Wechsel robuster und weniger abhängig vom Zufall der letzten Chatnachrichten.

### 8.3 Skalierbarkeit
Neue Themen lassen sich als zusätzliche Skills ergänzen, ohne die Grundverfassung neu zu überladen. Das macht das System langfristig pflegbarer.

### 8.4 Multi-Agent-Kompatibilität
Die Struktur eignet sich nicht nur für OpenCode, sondern auch für Koexistenz mit anderen Agentensystemen, weil globale Verhaltensgesetze, lokale Repo-Regeln und optionale Spezialpakete sauber voneinander getrennt sind.

---

## 9. Empfohlene nächste Schritte
1. Dateien an ihre Zielorte kopieren.
2. `BRAIN_UPLOAD.md` mit der neuen lokalen `AGENTS.md` abgleichen.
3. OpenCode neu starten.
4. In der ersten neuen Session bewusst einen Task wählen, der mindestens einen Skill laden sollte, um die Struktur praktisch zu testen.
5. Danach prüfen, welche Skills tatsächlich genutzt wurden und ob Beschreibungen oder Routing-Hinweise geschärft werden müssen.

---

## 10. Schlussbild
Die zentrale Idee dieses Regelsystems lautet: **Nicht alles immer laden, sondern das Richtige zur richtigen Zeit verfügbar machen.** Global sorgt für Charakter und Sicherheit, lokal für Architekturtreue und Skills für Präzision ohne Kontextmüll.

Wenn dieses System gut gepflegt wird, entsteht kein chaotischer Regelhaufen, sondern eine belastbare Betriebsverfassung für OpenCode und angrenzende Agentensysteme.
