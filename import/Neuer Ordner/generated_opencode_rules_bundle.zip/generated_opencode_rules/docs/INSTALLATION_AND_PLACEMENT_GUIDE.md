# Installations- und Ablageanleitung für das OpenCode-Regelsystem

## Ziel
Diese Anleitung erklärt, welche Datei wohin gehört und wie das Gesamtsetup praktisch aktiviert wird.

## Zielstruktur

```text
~/.config/opencode/
└── AGENTS.md                    # Globale Regeln

<repo-root>/
├── AGENTS.md                    # Lokale Repo-Regeln
└── .opencode/
    └── skills/
        ├── git-policy.md
        ├── agent-batching.md
        ├── handover-protocol.md
        ├── memory-shrink.md
        ├── three-zone-workflow.md
        ├── testing-protocols.md
        ├── secrets-management.md
        └── viron-stack-constraints.md
```

## Installationsschritte
1. Kopiere `global/AGENTS.md` nach `~/.config/opencode/AGENTS.md`.
2. Kopiere `project/AGENTS.md` in das Root deines Ziel-Repositories.
3. Kopiere den gesamten Ordner `project/.opencode/skills/` nach `<repo-root>/.opencode/skills/`.
4. Prüfe, dass `.opencode/knowledge/BRAIN_UPLOAD.md` bereits existiert oder angelegt ist.
5. Starte OpenCode neu.

## Nutzungslogik
- Globale `AGENTS.md`: persönlicher, repo-übergreifender Charakter.
- Lokale `AGENTS.md`: konkrete Repo-Verfassung.
- Skills: fokussierte Spezialregeln, die nur bei Bedarf geladen werden sollen.

## Empfehlung
Halte die Basisdateien schlank und verschiebe Spezialwissen in Skills. So bleibt der Hauptkontext kleiner und stabiler.
